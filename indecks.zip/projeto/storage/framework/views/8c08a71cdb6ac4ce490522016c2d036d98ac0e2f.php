<?php $__env->startSection('content'); ?>

<div class="right-side">
<div class="container-fluid">
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<!-- Starting of Dashboard Users area -->
<div class="section-padding add-product-1">
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="add-product-box customers">
        <div class="table-responsive">
            <div class="col-md-12">
                <?php if(Session::has('message')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <?php echo e(Session::get('message')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="add-product-header">
            <h2 class="title">Aniversariantes do Mês <i class="fa fa-calendar"></i></h2>
            </div>

            <hr/>
            <table id="product-table_wrapper" class="table table-striped table-hover products dt-responsive" cellspacing="0" width="100%">
                <thead>
                <tr>
                    <th>Dia</th>
                    <th>Semana</th>
                    <th>Mês</th>
                    <th>Nome</th>                                       
                    <th>E-mail</th>
                    <th>Usuário</th>  
                    <th>Ações</th>                                                      
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(date('m',strtotime($customer->data_de_nascimento)) == (date('m',strtotime('today')))): ?>
                <tr>
                <td><?php setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese'); echo ucfirst( utf8_encode( strftime("%d", strtotime($customer->data_de_nascimento)))); ?></td>
                <td><?php setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese'); echo ucfirst( utf8_encode( strftime("%A", strtotime($customer->data_de_nascimento)))); ?></td>
                <td><?php setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese'); echo ucfirst( utf8_encode( strftime("%B", strtotime($customer->data_de_nascimento)))); ?></td>
                <td><?php echo e($customer->nome); ?></td>                
                <td><?php echo e($customer->email); ?></td>
                <td><?php echo e($customer->usuario); ?></td>
                <td>

                    
                <form method="POST" action="<?php echo action('UsuarioAniversarianteController@destroy',['id' => $customer->id]); ?>">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="_method" value="DELETE">
                            <a href="aniversariantes/<?php echo e($customer->id); ?>" class="btn btn-primary product-btn"><i class="fa fa-check"></i> Detalhes</a>
                        </form>                        
                </td>
                
                <?php elseif(ucfirst(utf8_encode( strftime("%A", strtotime($customer->data_de_nascimento)))) == (ucfirst(utf8_encode( strftime("%B", strtotime('today')))))): ?>
                <td><?php setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese'); echo ucfirst( utf8_encode( strftime("%d", strtotime($customer->data_de_nascimento)))); ?></td>
                <td><?php setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese'); echo ucfirst( utf8_encode( strftime("%A", strtotime($customer->data_de_nascimento)))); ?></td>
                <td><?php setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese'); echo ucfirst( utf8_encode( strftime("%B", strtotime($customer->data_de_nascimento)))); ?></td>
                <td><?php echo e($customer->nome); ?></td>
                <td><?php echo e($customer->data_de_nascimento); ?></td>                        
                <td><?php echo e($customer->email); ?></td>
                <td><?php echo e($customer->usuario); ?></td>
                <td>                    
                 
                <a href="usuarios/<?php echo e($customer->id); ?>" class="btn btn-success product-btn"><i class="fa fa-eye"></i> Ver </a>
                <a href="usuarios/<?php echo e($customer->id); ?>/editar" class="btn btn-primary product-btn"><i class="fa fa-edit"></i> Editar </a>
                </td>
                <a href="javascript:;" data-href="<?php echo e(url('/')); ?>/admin/usuarios/<?php echo e($customer->id); ?>/deletar" data-toggle="modal" data-target="#confirma-deletar"class="btn btn-danger product-btn"><i class="fa fa-trash"></i></a>

                <?php else: ?> 
                <?php endif; ?>


                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <hr/>
    </div>
</div>
</div>
</div>
<!-- Fim da área de usuários do painel -->
</div>
</div>
</div>
</div>

<div class="modal table-modal fade" id="confirma-deletar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content panel-danger">
<div class="modal-header panel-heading">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
<h3 class="modal-title" id="myModalLabel"><i class="fa fa-exclamation-circle fa-fw"></i> Confirme a Exclusão</h3>
</div>
<div class="modal-body">
<h5>Você está prestes a excluir este colaborador.</h5>
<h4>Você deseja prosseguir?</h4>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-success" data-dismiss="modal"><i class="fa fa-fw fa-times"></i> Cancelar</button>
<a class="btn btn-danger btn-ok"><i class="fa fa-fw fa-trash"></i> Excluir</a>
</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<script>
$('#confirma-deletar').on('show.bs.modal', function(e) {
$(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.includes.masterpage-user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>