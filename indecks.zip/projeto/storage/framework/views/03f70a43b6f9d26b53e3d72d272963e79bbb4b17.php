<?php $__env->startSection('content'); ?>

<div class="right-side">
<div class="container-fluid">
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<!-- Starting of Dashboard add-product-1 area -->
<div class="section-padding add-product-1">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="add-product-box">
                <div class="add-product-header">
                    <h2 class="title">Adicionar Colaborador</h2>
                    <a href="<?php echo url('admin/usuarios'); ?>" class="btn btn-primary"><i class="fa fa-arrow-left"></i> voltar</a>
                </div>
                <hr/>
                <div id="response">                                        
                    <?php if($errors->has('email')): ?>
                        <div class="alert alert-danger alert-dismissable">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <?php echo e($errors->first('email')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($errors->has('password')): ?>
                        <div class="alert alert-danger alert-dismissable">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <?php echo e($errors->first('password')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <form method="POST" action="<?php echo action('UsuariosController@store'); ?>" class="form-horizontal" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>                    
                    <div class="form-group">
                        <label class="control-label col-sm-3" for="nome">Nome:*</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="nome" id="nome" placeholder="Informe seu nome" required>
                        </div>
                    </div>

                    <div class="form-group">
                    <label class="control-label col-sm-3" for="service_text">E-mail:* <span style="color: red; font-weight: bold;">(Será usado para login)</span></label>
                        <div class="col-sm-6">
                            <input type="email" class="form-control" name="email" placeholder="O e-mail será usado para fazer o login no sistema" id="email" required>
                        </div>
                    </div>

                    

                    <div class="form-group">
                        <label class="control-label col-sm-3" for="data_de_nascimento">Data de Nascimento:*</span></label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="data_de_nascimento" id="data_de_nascimento" placeholder="<?php echo date('d-m-Y H:i:s');?>" readonly required>
                        </div>
                    </div>
                <div class="form-group">
                <label class="control-label col-sm-3" for="descricao">Breve Descrição:*</label>
                <div class="col-sm-6">
                    <textarea class="form-control" name="descricao" id="descricao" rows="5" style="resize: vertical;"></textarea>
                </div>
            </div>

                    <div class="form-group">
                        <label class="control-label col-sm-3" for="usuario">Nome de Usuário:*</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="usuario" id="usuario" placeholder="Informe um nome de usuário">
                        </div>
                    </div>                                       
                    
                    <div class="form-group">
                        <label class="control-label col-sm-3" for="password">Senha:* <span style="color: red; font-weight: bold;">(Será usada para login)</span></label>
                        <div class="col-sm-6">
                            <input type="password" class="form-control" name="password" autocomplete="off" placeholder="Informe uma senha" id="password" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-3" for="password_confirmation">Confirme a Senha:*</label>
                        <div class="col-sm-6">
                    <input type="password" class="form-control" name="password_confirmation" placeholder="Confirma sua Senha">
                    </div>
                    </div>
                                

                    <hr/>
                    <div class="add-product-footer">
                        <button style="height: 41px;" name="addProduct_btn" type="submit" class="btn btn-primary"><i class="fa fa-plus-circle"></i> Adicionar Funcionário</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Fim da área do painel -->

</div>
</div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script type="text/javascript">
    
$(function(){
    var currentDate; // Mantém o dia clicado ao adicionar um novo evento
    var currentEvent; // Mantém o objeto de evento ao editar um evento
    $('#color').colorpicker(); // Colopicker
    $('#time').timepicker({
        minuteStep: 5,
        showInputs: false,
        disableFocus: true,
        showMeridian: false
    });  // Timepicker
});

</script>

    <script type="text/javascript">   
    $('#data_de_nascimento').datetimepicker({    
    changeMonth: true,
    changeYear: true,
    yearRange: '1930:', //definir o intervalo de anos
    dateFormat: 'dd-mm-yy',
    timeFormat: 'HH:mm:ss',    
    stepHour: 1,
    stepMinute: 1,
    stepSecond: 1,
}); 
</script>
<script type="text/javascript">
    
    bkLib.onDomLoaded(function() {
new nicEditor({fullPanel : true}).panelInstance('descricao');
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.includes.masterpage-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>