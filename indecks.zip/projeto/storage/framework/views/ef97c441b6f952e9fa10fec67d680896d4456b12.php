<?php $__env->startSection('content'); ?>

    <div class="right-side">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Starting of Dashboard add-product-1 area -->
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="add-product-box">
                                    <div class="add-product-header">
                                        <h2><i class="fa fa-fw fa-user"></i>Perfil</h2>
                                    </div>
                                    <hr/>
                                    <div id="response" class="col-md-12">
                                        <?php if(Session::has('message')): ?>
                                            <div class="alert alert-success alert-dismissable">
                                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                <?php echo e(Session::get('message')); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <form method="POST" action="<?php echo action('UserProfileController@update',['id' => $user->id]); ?>" class="form-horizontal" enctype="multipart/form-data">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="name">Nome*</label>
                                            <div class="col-sm-6">
                                                <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" id="name" placeholder="Nome Completo">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="username">Nomde de Usuário *</label>
                                            <div class="col-sm-6">
                                                <input type="text" class="form-control" name="username" value="<?php echo e($user->username); ?>" id="username" placeholder="Nome do Usuário">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="admin_email_address">E-mail *</label>
                                            <div class="col-sm-6">
                                                <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>" id="email" placeholder="E-mail" required readonly="true" disabled="disabled">
                                            </div>
                                        </div>

                                        <hr>                                        

                                        <div class="form-group">
                                        <label class="control-label col-sm-4" for="current_feature_photo">&nbsp; </label>
                                        <div class="col-sm-6">
                                        <?php if($user->foto == ''): ?>
                                        <img src="<?php echo e(URL::asset('assets/images/padrao.png')); ?>" style="max-width: 200px;" alt="Nenhuma foto adicionada" id="docfoto">
                                        <?php else: ?>
                                        <img src="<?php echo e(URL::asset('assets/images/userprofile')); ?>/<?php echo e($user->foto); ?>" style="border: 3px solid #ddd; max-width: 200px;" alt="Nenhuma foto adicionada" id="docfoto">
                                        <?php endif; ?>
                                        </div>
                                        </div>                                        
                                        <div class="form-group">
                                            <label class="control-label col-sm-4" for="foto">Foto de Perfil *</label>
                                            <div class="col-sm-6">
                                                <input type="file" accept="image/*" name="foto" class="hidden" onchange="readURL(this)" id="uploadFile"/>
                                                <div id="uploadTrigger" class="btn btn-default"><i class="fa fa-upload"></i> Adicionar Foto de Perfil</div><br><br>
                                                <p style="font-weight: bold; color: red;">Proporção da Imagem: (3:4)</p>
                                            </div>
                                        </div>

                                        <hr/>

                                        <div class="add-product-footer">
                                            <button name="addProduct_btn" type="submit" class="btn btn-primary"><i class="fa fa-refresh"></i> Atualizar</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard add-product-1 area -->
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        $("#uploadTrigger").click(function(){
            $("#uploadFile").click();
            $("#uploadFile").change(function(event) {
                $("#uploadTrigger").html($("#uploadFile").val());
            });
        });
        function readURL(input) {

            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#docfoto').attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }        
    </script>
   

<script src="<?php echo e(URL::asset('assets/js/jquery-latest.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/js/jquery.mask.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(URL::asset('assets/js/jquery.js')); ?>"></script>


<script src="<?php echo e(URL::asset('assets/js/jquery.mask.min.js')); ?>"></script>
<script type="text/javascript">
  // Mascara de CEP
var PostalcodeMaskBehavior = function (val) {
            return val.replace(/\D/g, '').length <= 9 ? '00000-000' : '00000-000';
        },
    PostalcodepOptions = {
        onKeyPress: function(val, e, field, options) {
        field.mask(PostalcodeMaskBehavior.apply({}, arguments), options);
      }
    };

$(function() {
    $('#postal_code').mask(PostalcodeMaskBehavior, PostalcodepOptions);
    //$(':input[name=cpfCnpj]').mask(CpfCnpjMaskBehavior, cpfCnpjpOptions);
})
//Mascara CEP

  // Mascara de CPF e CNPJ
var CpfCnpjMaskBehavior = function (val) {
            return val.replace(/\D/g, '').length <= 11 ? '000.000.000-009' : '00.000.000/0000-00';
        },
    cpfCnpjpOptions = {
        onKeyPress: function(val, e, field, options) {
        field.mask(CpfCnpjMaskBehavior.apply({}, arguments), options);
      }
    };

$(function() {
    $('#cpfcnpj').mask(CpfCnpjMaskBehavior, cpfCnpjpOptions);
    //$(':input[name=cpfCnpj]').mask(CpfCnpjMaskBehavior, cpfCnpjpOptions);
})
var PhoneMaskBehavior = function (val) {
            return val.replace(/\D/g, '').length <= 9 ? '(00)0000-0009' : '(00)0000-00009';
        },
    PhonepOptions = {
        onKeyPress: function(val, e, field, options) {
        field.mask(PhoneMaskBehavior.apply({}, arguments), options);
      }
    };

$(function() {
    $('#phone').mask(PhoneMaskBehavior, PhonepOptions);
    //$(':input[name=cpfCnpj]').mask(CpfCnpjMaskBehavior, cpfCnpjpOptions);
})
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.includes.masterpage-user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>