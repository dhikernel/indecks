<script type="text/javascript">
location.href = '<?php echo e(url('/')); ?>/usuario/login';
</script>