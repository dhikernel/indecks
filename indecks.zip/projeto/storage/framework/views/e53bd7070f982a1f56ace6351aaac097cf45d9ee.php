<?php $__env->startSection('content'); ?>

<div class="right-side">
<div class="container-fluid">
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <!-- Starting of Dashboard User Details -->
        <div class="section-padding add-product-1">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="add-product-box">
                        <div class="add-product-header">
                            <h2 class="title">Detalhes do Colaborador</h2>
                            <a href="<?php echo url('usuario/aniversariantes'); ?>" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Voltar</a>
                        </div>
                        <hr/>
                        <div id="imprimir">
                        <div class="table-responsive order-details-table">
                            <table class="table">                                
                                <tr>
                                    <td width="30%"><strong>Status da Conta: </strong></td>
                                    <?php if($customer->status != 0): ?>
                                        <td style="color: #008000;"> <strong>Ativo</strong></td>
                                    <?php else: ?>
                                        <td style="color: #ff0000;"><strong>Desativado</strong></td>
                                    <?php endif; ?>
                                </tr>
                                <tr>
                                    <td width="30%"><strong>Nome:</strong></td>
                                    <td><?php echo e($customer->nome); ?></td>
                                </tr>
                                <tr>
                                    <td width="30%"><strong>Usuário:</strong></td>
                                    <td><?php echo e($customer->usuario); ?></td>
                                </tr>
                                <tr>
                                    <td width="30%"><strong>E-mail:</strong></td>
                                    <td><?php echo e($customer->email); ?></td>
                                </tr>          
                                <tr>
                                    <td width="30%"><strong>Ingressou:</strong></td>
                                    <td><span><?php setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
echo ucfirst( utf8_encode( strftime("%A, %d de %B de %Y", strtotime($customer->criado_em)))); ?></span></td>
                                </tr>
                                <tr>
                                    <td width="30%"><strong>Foto de Perfl:</strong></td>
                                    <td>
                                    <?php if($customer->foto == ''): ?>
                                    <img style="max-width: 200px; max-height: 200px;" src="<?php echo e(URL::asset('assets/images/padrao.png')); ?>" width="auto" height="auto" />
                                    <?php else: ?>
                                        <img style="max-width: 200px; max-height: 200px;" src="<?php echo e(URL::asset('assets/images/userprofile')); ?>/<?php echo e($customer->foto); ?>" width="auto" height="auto" /><?php endif; ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
              <div class="row no-print">
              <div class="col-xs-12">
              <button style="float: right; margin-top:-2px; margin-right: 30px;" class="btn btn-primary" onclick="printDiv('imprimir');"><i class="fa fa-print"></i> Imprimir</button>                          
            </div>
            </div>
                        <hr />
                                              
                    </div>
                </div>
            </div>
            
        </div>
        <! - Fim dos detalhes do usuário do painel ->
        
    </div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script type="text/javascript">
function printDiv(imprimir){    
var printContents = document.getElementById('imprimir').innerHTML;
var originalContents = document.body.innerHTML;
document.body.innerHTML = printContents;
window.print();
document.body.innerHTML = originalContents;
window.close();         
}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.includes.masterpage-user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>