<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <?php /*<meta name="keywords" content="{{$code[0]->meta_keys}}">*/ ?>
    <meta name="author" content="InDecks">
    <title><?php echo e($settings[0]->title); ?></title>

    <link rel="icon" 
      type="image/png" 
      href="<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->favicon); ?>">

    <link href="<?php echo e(URL::asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/slicknav.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/owl.carousel.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/magnific-popup.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/genius-slider.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/responsive.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/jquery-ui.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/jquery-ui-timepicker-addon.css')); ?>" rel="stylesheet">
    <!-- Gallery Css -->
    <link rel='stylesheet' href='<?php echo e(URL::asset('assets/css/unite-gallery.css')); ?>' type='text/css' />
    <link rel='stylesheet' href='<?php echo e(URL::asset('assets/css/ug-theme-default.css')); ?>' type='text/css' />

</head>
<body style="background-color: #f1f1f1;">


<?php echo $__env->yieldContent('content'); ?>


    <script src="<?php echo e(URL::asset('assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/wow.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/jquery.counterup.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/jquery.slicknav.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/main.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/genius-slider.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(URL::asset('assets/js/jquery-ui.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(URL::asset('assets/js/jquery-ui-timepicker-addon.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('assets/js/jquery-ui-timepicker-pt-BR.js')); ?>"></script>
    <script type='text/javascript' src='<?php echo e(URL::asset('assets/js/unitegallery.min.js')); ?>'></script>
    <script type='text/javascript' src='<?php echo e(URL::asset('assets/js/ug-theme-compact.js')); ?>'></script>
    <?php /*{!! $code[0]->google_analytics !!}*/ ?>
    <?php echo $__env->yieldContent('footer'); ?>
<?php /*
    <script>

        $(window).load(function(){
            setTimeout(function(){
            $('#cover').fadeOut(1000);
            },1000)
        });

    </script>
*/ ?>    
</body>
</html>