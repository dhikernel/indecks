<?php $__env->startSection('content'); ?>

    <div class="right-side">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Starting of Dashboard add-product-1 area -->
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="add-product-box">
                                    <div class="add-product-header">
                                        <h2 class="title">Perfil <i class="fa fa-pencil-square-o"></i></h2>
                                    </div>
                                    <hr/>
                                    <div id="response" class="col-md-12">
                                        <?php if(Session::has('message')): ?>
                                            <div class="alert alert-success alert-dismissable">
                                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                <?php echo e(Session::get('message')); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <form method="POST" action="<?php echo action('AdminProfileController@update',['id' => $admin->id]); ?>" class="form-horizontal" enctype="multipart/form-data">
                                        <?php echo e(csrf_field()); ?>

                                        <input type="hidden" name="_method" value="PATCH">
                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="admin_current_photo">Foto de Perfil *</label>
                                            <div class="col-sm-3">
                                                <img id="adminimg" src="<?php echo e(url('/')); ?>/assets/images/admin/<?php echo e($admin->photo); ?>" alt="">
                                            </div>
                                            <div class="col-sm-5">
                                                <input class="hidden" onchange="readURL(this)" id="uploadFile" name="photo" type="file">

                                                <button name="admin_image_btn" id="uploadTrigger" onclick="uploadclick()" type="button" class="btn btn-primary"><i class="fa fa-cloud-upload"></i> Alterar foto</button>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="admin_name">Nome *</label>
                                            <div class="col-sm-6">
                                                <input type="text" class="form-control" name="name" value="<?php echo e($admin->name); ?>" id="admin_name" placeholder="Nome" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="admin_email_address">E-mail *</label>
                                            <div class="col-sm-6">
                                                <?php if($admin->role == "administrator"): ?>
                                                    <input type="email" class="form-control" name="email" value="<?php echo e($admin->email); ?>" id="admin_email_address" placeholder="E-mail" required>
                                                <?php else: ?>
                                                    <input type="email" class="form-control" name="email" value="<?php echo e($admin->email); ?>" id="admin_email_address" placeholder="Endereço de E-mail" required disabled>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="admin_phone_number">Telefone *</label>
                                            <div class="col-sm-6">
                                                <input type="text" class="form-control" name="phone" value="<?php echo e($admin->phone); ?>" id="phone" laceholder="Número de Telefone" required>
                                            </div>
                                        </div>
                                        <hr/>
                                        <div class="add-product-footer">
                                            <button type="submit" class="btn btn-primary">
                                             <i class="fa fa-refresh"></i> Atualizar Perfil</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard add-product-1 area -->


                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script src="<?php echo e(URL::asset('assets/js/jquery.mask.min.js')); ?>"></script>
<script type="text/javascript">
var PhoneMaskBehavior = function (val) {
            return val.replace(/\D/g, '').length <= 10 ? '(00) 0000-00009' : '(00) 9.0000-0000';
        },
    PhonepOptions = {
        onKeyPress: function(val, e, field, options) {
        field.mask(PhoneMaskBehavior.apply({}, arguments), options);
      }
    };

$(function() {
    $('#phone').mask(PhoneMaskBehavior, PhonepOptions);
    
})
        function uploadclick(){
            $("#uploadFile").click();
            $("#uploadFile").change(function(event) {
                $("#uploadTrigger").html($("#uploadFile").val());
            });
        }

        function readURL(input) {

            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#adminimg').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.includes.masterpage-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>