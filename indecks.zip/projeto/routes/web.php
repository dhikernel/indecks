<?php

use App\UsersModel;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Aqui é onde você pode registrar rotas da web para seu aplicativo. Estes
| rotas são carregadas pelo RouteServiceProvider dentro de um grupo que
| contém o grupo de middleware "web". Agora crie algo ótimo!
|
*/
Route::get('/', 'FrontEndController@index');

Route::get('/admin', function () {
    return view('admin.index');
})->name('admin.login');

Route::get('/login', function () {
    return view('admin.login');
});

Auth::routes();

Route::get('admin/settings/logo', 'SettingsController@logoform');
Route::get('admin/settings/favicon', 'SettingsController@faviconform');
Route::get('admin/settings/conteudos', 'SettingsController@contentsform');
Route::get('admin/settings/endereco', 'SettingsController@addressform');
Route::get('admin/settings/rodape', 'SettingsController@footerform');
Route::post('admin/settings/title', 'SettingsController@title');
Route::post('admin/settings/favicon', 'SettingsController@favicon');
Route::post('admin/settings/footer', 'SettingsController@footer');
Route::post('admin/settings/logo', 'SettingsController@logo');
Route::resource('/admin/settings', 'SettingsController');
Route::get('/admin/administradores/cadastrar', 'FuncionariosController@cadastrar');
Route::resource('/admin/administradores', 'FuncionariosController');
Route::post('/admin/adminpassword/change/{id}', 'AdminProfileController@changepass');
Route::get('/admin/mudar-senha', 'AdminProfileController@password');
Route::resource('/admin/perfil', 'AdminProfileController');
Route::get('/admin/usuarios/status/{id}/{status}', 'UsuariosController@status');
Route::get('/admin/usuarios/cadastrar', 'UsuariosController@cadastrar');
Route::get('/admin/usuarios/{id}/editar', 'UsuariosController@editar');
Route::get('/admin/usuarios/{id}/deletar', 'UsuariosController@deletar');
Route::resource('/admin/usuarios', 'UsuariosController');
Route::get('usuario/aniversarianteslista', 'UserProfileController@index')->name('user.painel');
Route::post('/usuario/senha/change/{id}', 'UserProfileController@changepass');
Route::get('/usuario/senha', 'UserProfileController@password');
Route::get('/usuario/perfil', 'UserProfileController@profile');
Route::post('/usuario/update/{id}', 'UserProfileController@update');
Route::resource('usuario/aniversariantes', 'UsuarioAniversarianteController');
Route::get('/usuario/login', 'Auth\ProfileLoginController@showLoginFrom')->name('user.login');
Route::post('/usuario/login', 'Auth\ProfileLoginController@login')->name('user.login.submit');
//Route::get('/usuario/cadastre-se', 'Auth\ProfileRegistrationController@showRegistrationForm')->name('user.reg');
//Route::post('/usuario/cadastre-se', 'Auth\ProfileRegistrationController@register')->name('user.reg.submit');
//Route::get('/usuario/esqueceu-sua-senha', 'Auth\ProfileResetPassController@showForgotForm')->name('user.forgotpass');
//Route::post('/usuario/esqueceu-sua-senha', 'Auth\ProfileResetPassController@resetPass')->name('user.forgotpass.submit');

