@extends('includes.masterpage')

@section('content')

    <section class="login-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 col-sm-12">
                    <div class="login-form">
                        <div class="section-login" style="text-align: center;">
                        <img style="margin-bottom: 20px;" src="{{ URL::asset('assets/images/logo/logo-login.png')}}" alt="logo do site">
                            </div>
                        <div class="login-title text-center" style="text-transform: uppercase; font-weight: bold;">Recuperar sua senha</div>

                        <form method="POST" action="{{ route('user.forgotpass.submit') }}">
                            {{ csrf_field() }}
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-envelope"></i>
                                    </div>
                                    <input type="email" name="email" value="{{ old('email') }}" class="form-control" placeholder="Endereço de E-mail" required>
                                </div>
                            </div>

                            <div id="resp">
                                @if(Session::has('success'))
                                    <div class="alert alert-success alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        {{ Session::get('success') }}
                                    </div>
                                @endif
                                @if(Session::has('error'))
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        {{ Session::get('error') }}
                                    </div>
                                @endif
                            </div>

                            <div class="form-group text-center">
                                    <button type="submit" class="btn btn-primary" name="button">
                              <span class="glyphicon glyphicon-envelope"></span> &nbsp; Enviar
                              </button>
                              </div>                            
                                <hr>
                            <p style="text-align: center; margin-bottom: 60px;"><a href="{{route('user.login')}}" class="col-md-12">Já tem conta? Login</a></p>

                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
                  <div class="col-lg-12">
                    <div class="login-footer text-center" style="margin-top: -30px;">
                      <b>Desenvolvido Por</b> <a style="font-weight: bold; color: #838383;" href="{{url('/')}}" target="_blank"><i class="fa fa-barcode" style="font-weight: bold; border: 1px solid #838383; padding: 1px 4px;"></i> In <span style="color:#76b14c;">Decks</span></a>
                      <p style="font-weight: bold;">Copyright © <?php echo date('Y') ?> Todos os Direitos Reservados.</p>
                    </div>
                  </div>
                </div> 
    </section>


@stop

@section('footer')

@stop