<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="Documentação Simples para o projeto InDecks.">
    <meta name="author" content="Diego San">

    <title>InDecks - Admin Panel</title>

    <!-- Bootstrap Core CSS -->
    <link href="{{ URL::asset('assets/css/bootstrap.min.css')}}" rel="stylesheet">
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="{{ URL::asset('assets/css/genius-admin.css')}}" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body style="background-color:#2A3F54; border-top:3px solid #FFF;">
<br><br><br><br><br><br><br><br><br>
<div class="container body">
      <div class="main_container">
        <!-- page content -->
        <div class="col-md-12">
          <div class="col-middle">
            <div class="text-center text-center">
              <h1 style="font-size:150px; color:#FFF;" class="error-number">404</h1>
              <div style="color:#FFF; font-weight:bold;" align="center">Nenhuma página encontrada.</div>
              <h2 style="color:#FFF;">Desculpe, mas não conseguimos encontrar esta página</h2>
              <p style="color:#FFF; font-weight:bold;">Esta página que você está procurando não existe</p>
              <div class="mid_center">
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->
      </div>
    </div>

<footer id="footer">
    <div align="center" class="container">
        <div class="row">
            <div class="col-xs-12">
                <p style="color:#FFF;"><?php echo date('Y'); ?> Desenvolvido por <strong>Art.ficial Intelligence</strong></p>
            </div>
        </div>
    </div>
</footer>
</body>
</html>