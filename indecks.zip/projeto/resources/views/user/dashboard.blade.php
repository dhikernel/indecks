@extends('user.includes.masterpage-user')

@section('content')

@if (Auth::user()->status == 0)
<script type="text/javascript">

window.onload = function(){

    document.getElementById('logout-form').submit();
}

</script>
<form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
</form>
@else
    <div class="right-side">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Starting of Dashboard header items area -->
                    <div class="panel panel-default admin">
                        <div class="panel-heading admin-title">Painel de Controle</div>
                        <div class="panel-body dashboard-body">
                            <div class="dashboard-header-area">
                                <div class="row">
                                    
                                  
                                   Hereeee HereeeeHereeee HereeeeHereeee HereeeeHereeee HereeeeHereeee HereeeeHereeee HereeeeHereeee HereeeeHereeee Hereeee Hereeee HereeeeHereeee HereeeeHereeee HereeeeHereeee HereeeeHereeee HereeeeHereeee HereeeeHereeee HereeeeHereeee Hereeee Hereeee HereeeeHereeee HereeeeHereeee HereeeeHereeee HereeeeHereeee HereeeeHereeee HereeeeHereeee HereeeeHereeee Hereeee Hereeee HereeeeHereeee HereeeeHereeee HereeeeHereeee HereeeeHereeee HereeeeHereeee HereeeeHereeee HereeeeHereeee Hereeee
                         
                                
                                
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard header items area -->

                </div>
            </div>
        </div>
    </div>
@endif
@stop

@section('footer')

@stop