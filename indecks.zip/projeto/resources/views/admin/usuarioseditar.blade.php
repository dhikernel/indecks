@extends('admin.includes.masterpage-admin')

@section('content')

    <div class="right-side">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Início da área do colaborador do painel de controle -->
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="add-product-box">
                                    <div class="add-product-header">
                                        <h2 class="title">Editar Colaborador</h2>
                                        <a href="{!! url('admin/usuarios') !!}" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Voltar</a>
                                    </div>
                                    <hr/>
                                    <form method="POST" action="{!! action('UsuariosController@update',['id' => $customer->id]) !!}" class="form-horizontal form-label-left" enctype="multipart/form-data">
                                        {{csrf_field()}}
                                        <input type="hidden" name="_method" value="PATCH">

                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="edit_customer_display_name">Nome*</span></label>
                                            <div class="col-sm-6">
                                                <input type="text" class="form-control" name="name" value="{{$customer->nome}}" id="name" placeholder="Nome" required>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="email">E-mail*</span></label>
                                            <div class="col-sm-6">
                                                <input type="email" name="email" id="email" class="form-control" placeholder="Informe seu e-mail" value="{{$customer->email}}" required>                
                                            </div>
                                        </div>                                       

                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="data_de_nascimento">Data de Nascimento*</span></label>
                                            <div class="col-sm-6">
                                                <input type="text" class="form-control" name="data_de_nascimento" value="{{$customer->data_de_nascimento}}" id="data_de_nascimento" placeholder="Data de Nascimento" required>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="descricao">Breve Descrição:*</label>
                                            <div class="col-sm-6">
                                            <textarea class="form-control" name="descricao" id="descricao" rows="5" style="resize: vertical;">{{$customer->descricao}}</textarea>
                                            </div>
                                        </div>      

                                       <div class="form-group">
                                            <label class="control-label col-sm-3" for="usuario">Usuário*</span></label>
                                            <div class="col-sm-6">
                                                <input type="text" class="form-control" name="usuario" value="{{$customer->usuario}}" id="usuario" placeholder="Nome de Usuário" required>
                                            </div>
                                        </div> 

                                       
                                        <hr/>
                                        <div class="add-product-footer">
                                            <button style="height: 41px;" name="addProduct_btn" type="submit" class="btn btn-primary"><i class="fa fa-refresh"></i> Atualizar Usuário</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard Edit customer area -->

                </div>
            </div>
        </div>
    </div>

@stop

@section('footer')
    <script type="text/javascript">    
 $('#data_de_nascimento').datetimepicker({    
    changeMonth: true,
    changeYear: true,
    yearRange: '1930:', //definir o intervalo de anos
    dateFormat: 'dd-mm-yy',
    timeFormat: 'HH:mm:ss',    
    stepHour: 1,
    stepMinute: 1,
    stepSecond: 1,
}); 
</script>
<script type="text/javascript">
    
    bkLib.onDomLoaded(function() {
new nicEditor({fullPanel : true}).panelInstance('descricao');
});

</script>
@stop