@extends('admin.includes.masterpage-admin')

@section('content')

<div class="right-side">
<div class="container-fluid">
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <!-- Starting of Dashboard User Details -->
        <div class="section-padding add-product-1">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="add-product-box">
                        <div class="add-product-header">
                            <h2 class="title">Detalhes do Usuário</h2>
                            <a href="{!! url('admin/usuarios') !!}" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Voltar</a>
                        </div>
                        <hr/>
                        <div id="imprimir">
                        <div class="table-responsive order-details-table">
                            <table class="table">                                
                                <tr>
                                    <td width="30%"><strong>Status da Conta: </strong></td>
                                    @if($customer->status != 0)
                                        <td style="color: #008000;"> <strong>Ativo</strong></td>
                                    @else
                                        <td style="color: #ff0000;"><strong>Desativado</strong></td>
                                    @endif
                                </tr>
                                <tr>
                                    <td width="30%"><strong>Nome:</strong></td>
                                    <td>{{$customer->nome}}</td>
                                </tr>
                                <tr>
                                    <td width="30%"><strong>Usuário:</strong></td>
                                    <td>{{$customer->usuario}}</td>
                                </tr>
                                <tr>
                                    <td width="30%"><strong>E-mail:</strong></td>
                                    <td>{{$customer->email}}</td>
                                </tr>          
                                <tr>
                                    <td width="30%"><strong>Ingressou:</strong></td>
                                    <td><span><?php setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
echo ucfirst( utf8_encode( strftime("%A, %d de %B de %Y", strtotime($customer->criado_em)))); ?></span></td>
                                </tr>
                                <tr>
                                    <td width="30%"><strong>Foto de Perfl:</strong></td>
                                    <td>
                                    @if($customer->foto == '')
                                    <img style="border: 3px solid #ddd; max-width: 200px; max-height: 200px;" src="{{ URL::asset('assets/images/padrao.png')}}" width="auto" height="auto" />
                                    @else
                                        <img style="border: 3px solid #ddd; max-width: 200px; max-height: 200px;" src="{{ URL::asset('assets/images/userprofile')}}/{{$customer->foto}}" width="auto" height="auto" />@endif
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
              <div class="row no-print">
              <div class="col-xs-12">
              <button style="float: right; margin-top:-2px; margin-right: 30px;" class="btn btn-primary" onclick="printDiv('imprimir');"><i class="fa fa-print"></i> Imprimir</button>                          
            </div>
            </div>
                        <hr />
                                              
                    </div>
                </div>
            </div>
            
        </div>
        <! - Fim dos detalhes do usuário do painel ->
        
    </div>
</div>
</div>
</div>

@stop

@section('footer')
<script type="text/javascript">
function printDiv(imprimir){    
var printContents = document.getElementById('imprimir').innerHTML;
var originalContents = document.body.innerHTML;
document.body.innerHTML = printContents;
window.print();
document.body.innerHTML = originalContents;
window.close();         
}
</script>

@stop