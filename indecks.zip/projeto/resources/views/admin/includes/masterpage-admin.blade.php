<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
<meta name="description" content="Sistema Indecks.">
<meta name="author" content="Diego San">
<link rel="icon" type="image/png" href="{{url('/')}}/assets/images/{{$settings[0]->favicon}}" />
<title>{{$settings[0]->title}} Painel Administrativo</title>
<!-- Bootstrap Core CSS -->
<link href="{{ URL::asset('assets/css/bootstrap.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/css/custom.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/css/font-awesome.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/css/perfect-scrollbar.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/css/bootstrap-tags.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/css/dataTables.bootstrap.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/css/responsive.bootstrap.min.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/css/bootstrap-coloroicker.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/css/jquery-ui.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/css/jquery-ui-timepicker-addon.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/css/chosen.min.css')}}" rel="stylesheet">
<!-- Custom CSS -->
<link href="{{ URL::asset('assets/css/admin-style.css')}}" rel="stylesheet">
<link href="{{ URL::asset('assets/css/admin-responsive.css')}}" rel="stylesheet">
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->

</head>
<div class="dashboard-wrapper">
    <div class="left-side">
        <!-- Início da área do menu Barra lateral do painel -->
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    {{--<h2>Painel de Controle</h2>--}}
                </div>

                <div class="navbar-right">
                    <button type="button" id="sidebarCollapse" class="navbar-btn">
                        <span></span>
                        <span></span>
                        <span></span>
                    </button>
                </div>
            </div>
        </nav>

        <div class="dashboard-sidebar-area">            
            <div class="sidebar-menu-body">
                <nav id="sidebar-menu">
                    <div style="text-align: center;" class="sidebar-header">
                        <a href="{!! url('admin/usuarios') !!}">
                        <img src="{{ URL::asset('assets/images/logo')}}/{{$settings[0]->logo}}" alt="Logo do Sistemas">
                    </a>
                    </div>
                    <ul class="list-unstyled profile">
                        <li class="active">
                            <div class="row">
                                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                                    
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    @if (Auth::user()->photo == '')
                                    <img style="margin-left: 20px; margin-right: 20px; float: left;" src="{{url('assets/images/padrao.png')}}" alt="Foto de Perfil">
                                    @else
                                    <img style="margin-left: 20px; margin-right: 20px; float: left;" src="{{url('/')}}/assets/images/admin/{{Auth::user()->photo}}" alt="Foto de Perfil">
                                    @endif
                                    <a style=";color: #fff;text-transform: uppercase;font-weight: bold; margin-bottom: 0;margin-top: 0;text-shadow: 1px 1px #000;" href="#homeSubmenu" data-toggle="collapse" aria-expanded="false">{{ Auth::user()->name }}<span>{{ ucfirst(Auth::user()->role) }}</span></a>

                                </div>
                            </div>
                            <ul class="collapse list-unstyled profile-submenu" id="homeSubmenu">
                                <li><a href="{!! url('admin/perfil') !!}"><i class="fa fa-fw fa-user"></i> Editar Perfil</a></li>
                                <li><a href="{!! url('admin/mudar-senha') !!}"><i class="fa fa-fw fa-lock"></i> Mudar Senha</a></li>
                                <li class="divider"></li>
                                <li>
                                    <a href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <i class="fa fa-fw fa-sign-out"></i> Sair</a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        {{ csrf_field() }}
                                    </form>
                                </li>
                            </ul>
                        </li>
                    </ul>
                    <ul class="list-unstyled components">                        
                        <li>
                            <a href="{!! url('admin/usuarios') !!}"><i class="fa fa-fw fa-calendar"></i> Aniversariante do Mês</a>
                        </li>    
                        <br>                    
                        <h6 style="padding-left: 10px; color: #fff; text-transform: uppercase; letter-spacing: .5px; font-weight: bold; margin-bottom: 0; margin-top: 0; text-shadow: 1px 1px #000;"><i class="fa fa-fw fa-info-circle"></i> Geral</h6>
                        <br>                        
                        <li>
                            <a href="#rh" data-toggle="collapse" aria-expanded="false"><i class="fa fa-fw fa-users"></i> Colaboradores</a>
                            <ul class="collapse list-unstyled submenu" id="rh">
                                <li><a href="{!! url('admin/usuarios/cadastrar') !!}"><i class="fa fa-fw fa-plus-square fa fa-fw fa-user"></i>Cadastrar Colaborador</a></li>      
                            </ul>
                        </li>                                                             
                            <br>
                        <h6 style="padding-left: 10px; color: #fff; text-transform: uppercase; letter-spacing: .5px; font-weight: bold; margin-bottom: 0; margin-top: 0; text-shadow: 1px 1px #000;"><i class="fa fa-fw fa-cog"></i> Definicões</h6>
                        <br>
                        @if(Auth::user()->role == "administrator")
                            <li>
                                <a href="{!! url('admin/administradores') !!}"><i class="fa fa-fw fa-user-secret"></i> Administradores</a>
                            </li>                                                            
                                    <li><a href="{!! url('admin/settings/logo') !!}"><i class="fa fa-area-chart"></i> Logo</a></li>
                                    <li><a href="{!! url('admin/settings/favicon') !!}"><i class="fa fa-dot-circle-o"></i> Favicon</a></li>
                                    <li><a href="{!! url('admin/settings/conteudos') !!}"><i class="fa fa-desktop"></i> Definições do Sistema</a></li>
                                    <li><a href="{!! url('admin/settings/rodape') !!}"><i class="fa fa-fw fa-code"></i> Rodapé</a></li>
                                
                            
                        @endif
                    </ul>
                </nav>
            </div>
        </div>
        <!-- Fim da área do menu Barra lateral do painel -->
    </div>

    @yield('content')

</div>

<!-- /#wrapper -->
<script>
    var baseUrl = '{!! url('/') !!}';
</script>
<!-- jQuery -->
<script src="{{ URL::asset('assets/js/jquery.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/perfect-scrollbar.jquery.min.js')}}"></script>
<!-- Bootstrap Core JavaScript -->

<script src="{{ URL::asset('assets/js/bootstrap.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/bootstrap-tags.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/jquery.dataTables.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/dataTables.bootstrap.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/dataTables.responsive.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/responsive.bootstrap.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/jquery.canvasjs.min.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('assets/js/plugin/nicEdit.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('assets/js/jquery-ui.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('assets/js/jquery-ui-timepicker-addon.js')}}"></script><script type="text/javascript" src="{{ URL::asset('assets/js/jquery-ui-timepicker-pt-BR.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('assets/js/chosen.jquery.min.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('assets/js/js-yaml.min.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('assets/js/admin-main.js')}}"></script>
@yield('footer')
</body>
</html>


