@extends('includes.masterpage')

@section('content')

    <section class="login-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 col-sm-12">
                    <div class="login-form">
                        <div class="section-login" style="text-align: center;">
                        <img style="margin-bottom: 20px;" src="{{ URL::asset('assets/images/logo/logo-login.png')}}" alt="logo do site">
                            </div>

                        <div style="text-align:center; text-transform: uppercase; font-weight: bold;" class="login-title">Cadastre-se</div>

                        <form action="{{route('user.reg.submit')}}" method="post">
                            {{csrf_field()}}
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-user"></i>
                                    </div>
                                    <input type="text" name="name" class="form-control" placeholder="Informe seu nome completo" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-envelope"></i>
                                    </div>
                                    <input type="email" name="email" class="form-control" placeholder="Informe seu e-mail">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-qrcode"></i>
                                    </div>
                                    <input type="text" name="cpfcnpj" id="cpfcnpj" class="form-control" placeholder="Informe seu CPF ou CNPJ">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-file-text-o"></i>
                                    </div>
                                    <input type="text" name="social_name" id="social_name" class="form-control" placeholder="Razão Social">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-file-code-o"></i>
                                    </div>
                                    <input type="text" name="rg" class="form-control" placeholder="Informe seu RG">
                                </div>
                            </div>

                            <div class="form-group">
                            <div class="input-group">
                            <div class="input-group-addon">
                            <i class="fa fa-male"></i>|<i class="fa fa-female"></i>
                            </div>    
                            <select class="form-control" name="gender" id="gender">
                            <option value="">Informe seu Genero</option>
                            <option value="Masculino">Masculino</option>
                            <option value="Feminino">Feminino</option>                            
                            </select>                            
                            </div>
                            </div>                       

                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" name="date_of_birth" id="date_of_birth" class="form-control" placeholder="01-01-1950 00-00-00" readonly value="01-01-1950 00-00-00">
                                </div>
                            </div>                            

                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-mobile"></i>
                                    </div>
                                    <input type="text" name="phone" id="phone" class="form-control" placeholder="Informe seu celular">
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-map-marker"></i>
                                    </div>
                                    <input type="text" name="postal_code" id="postal_code" class="form-control" placeholder="Informe seu CEP">
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-road"></i>
                                    </div>
                                    <input type="text" name="address" id="address" class="form-control" placeholder="Endereço">
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-home"></i>|<i class="fa fa-home"></i>
                                    </div>
                                    <input type="text" name="neighborhood" id="neighborhood" class="form-control" placeholder="Bairro">
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-adjust"></i>
                                    </div>
                                    <input type="text" name="complement" id="complement" class="form-control" placeholder="Complemento">
                                </div>
                            </div>                           

                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-building"></i><i class="fa fa-building-o"></i>
                                    </div>
                                    <input type="text" name="city" id="city" class="form-control" placeholder="Cidade">
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-university"></i>
                                    </div>                                    
                                    <select name="state" id="state" class="form-control">
                                    <option value="">Selecione seu estado</option>
                                    <option value="AC">Acre</option>
                                        <option value="AL">Alagoas</option>
                                        <option value="AP">Amapá</option>
                                        <option value="AM">Amazonas</option>
                                        <option value="BA">Bahia</option>
                                        <option value="CE">Ceará</option>
                                        <option value="DF">Distrito Federal</option>
                                        <option value="ES">Espírito Santo</option>
                                        <option value="GO">Goiás</option>
                                        <option value="MA">Maranhão</option>
                                        <option value="MT">Mato Grosso</option>
                                        <option value="MS">Mato Grosso do Sul</option>
                                        <option value="MG">Minas Gerais</option>
                                        <option value="PA">Pará</option>
                                        <option value="PB">Paraíba</option>
                                        <option value="PR">Paraná</option>
                                        <option value="PE">Pernambuco</option>
                                        <option value="PI">Piauí</option>
                                        <option value="RJ">Rio de Janeiro</option>
                                        <option value="RN">Rio Grande do Norte</option>
                                        <option value="RS">Rio Grande do Sul</option>
                                        <option value="RO">Rondônia</option>
                                        <option value="RR">Roraima</option>
                                        <option value="SC">Santa Catarina</option>
                                        <option value="SP">São Paulo</option>
                                        <option value="SE">Sergipe</option>
                                        <option value="TO">Tocantins</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-home"></i>
                                    </div>
                                    <input type="text" name="number" id="number" class="form-control" placeholder="Número">
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-user"></i>
                                    </div>
                                    <input type="text" name="username" id="username" class="form-control" placeholder="Nome de Usuário">
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-unlock-alt"></i>
                                    </div>
                                    <input type="password" class="form-control" name="password" placeholder="Senha">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-lock"></i>
                                    </div>
                                    <input type="password" class="form-control" name="password_confirmation" placeholder="Confirma sua Senha">
                                </div>
                            </div>
                            <div id="resp" class="col-md-12">
                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong style="color: #d9534f;">* O nome é obrigatório!</strong>
                                    </span>
                                @endif
                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong style="color: #d9534f;">* Verfique se o e-mail está correto!</strong>
                                    </span>
                                @endif
                                @if ($errors->has('password'))
                                    <span class="help-block">
                                    <strong style="color: #d9534f;">* Verifique sua senha!</strong>
                                </span>
                                @endif
                            </div>
                            <div class="form-group text-center">

                                <button style="height: 41px;" type="submit" class="btn btn-primary" name="button">
                              <span class="glyphicon glyphicon glyphicon glyphicon-edit"></span> &nbsp; Cadastre-se
                              </button>                                
                                <br><br>
                                <p><a href="{{route('user.login')}}" class="col-md-12">Já tem conta? Faça Login!</a></p>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

@stop

@section('footer')
<script type="text/javascript">    
$('#date_of_birth').datetimepicker({    
    changeMonth: true,
    changeYear: true,        
    dateFormat: 'dd-mm-yy',
    timeFormat: 'HH:mm:ss',    
    stepHour: 1,
    stepMinute: 1,
    stepSecond: 1,
});
</script>
<?php /*<script src="{{ URL::asset('assets/js/jquery-latest.min.js')}}"></script>*/ ?>
<script src="{{ URL::asset('assets/js/jquery.mask.min.js')}}"></script>
    <script type="text/javascript" src="{{ URL::asset('assets/js/jquery.js')}}"></script>
    
    <script type="text/javascript">
        $("#postal_code").focusout(function(){
            //Início do Comando AJAX
            $.ajax({
                //O campo URL diz o caminho de onde virá os dados
                //É importante concatenar o valor digitado no CEP
                url: 'https://viacep.com.br/ws/'+$(this).val()+'/json/unicode/',
                //Aqui você deve preencher o tipo de dados que será lido,
                //no caso, estamos lendo JSON.
                dataType: 'json',
                //SUCESS é referente a função que será executada caso
                //ele consiga ler a fonte de dados com sucesso.
                //O parâmetro dentro da função se refere ao nome da variável
                //que você vai dar para ler esse objeto.
                success: function(resposta){
                    //Agora basta definir os valores que você deseja preencher
                    //automaticamente nos campos acima.
                    $("#address").val(resposta.logradouro);
                    $("#complement").val(resposta.complemento);
                    $("#neighborhood").val(resposta.bairro);
                    $("#city").val(resposta.localidade);
                    $("#state").val(resposta.uf);
                    //Vamos incluir para que o Número seja focado automaticamente
                    //melhorando a experiência do usuário
                    $("#number").focus();
                }
            });
        });
    </script>

<script src="{{ URL::asset('assets/js/jquery.mask.min.js')}}"></script>
<script type="text/javascript">
  // Mascara de CEP
var PostalcodeMaskBehavior = function (val) {
            return val.replace(/\D/g, '').length <= 9 ? '00000-000' : '00000-000';
        },
    PostalcodepOptions = {
        onKeyPress: function(val, e, field, options) {
        field.mask(PostalcodeMaskBehavior.apply({}, arguments), options);
      }
    };

$(function() {
    $('#postal_code').mask(PostalcodeMaskBehavior, PostalcodepOptions);
    //$(':input[name=cpfCnpj]').mask(CpfCnpjMaskBehavior, cpfCnpjpOptions);
})
//Mascara CEP

  // Mascara de CPF e CNPJ
var CpfCnpjMaskBehavior = function (val) {
            return val.replace(/\D/g, '').length <= 11 ? '000.000.000-009' : '00.000.000/0000-00';
        },
    cpfCnpjpOptions = {
        onKeyPress: function(val, e, field, options) {
        field.mask(CpfCnpjMaskBehavior.apply({}, arguments), options);
      }
    };

$(function() {
    $('#cpfcnpj').mask(CpfCnpjMaskBehavior, cpfCnpjpOptions);
    //$(':input[name=cpfCnpj]').mask(CpfCnpjMaskBehavior, cpfCnpjpOptions);
})
var PhoneMaskBehavior = function (val) {
            return val.replace(/\D/g, '').length <= 9 ? '(00)0000-0009' : '(00)0000-00009';
        },
    PhonepOptions = {
        onKeyPress: function(val, e, field, options) {
        field.mask(PhoneMaskBehavior.apply({}, arguments), options);
      }
    };

$(function() {
    $('#phone').mask(PhoneMaskBehavior, PhonepOptions);
    //$(':input[name=cpfCnpj]').mask(CpfCnpjMaskBehavior, cpfCnpjpOptions);
})
</script>
@stop