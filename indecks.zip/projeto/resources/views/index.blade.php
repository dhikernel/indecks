<script type="text/javascript">
location.href = '{{url('/')}}/usuario/login';
</script>