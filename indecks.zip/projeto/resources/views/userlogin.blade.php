@extends('includes.masterpage')

@section('content')

<section class="login-area">
<div class="container">
<div class="row">
    <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 col-sm-12">
        <div class="login-form">
            <div class="section-login" style="text-align: center;">
            <img style="height: 100px; margin-bottom:25px;" src="{{ URL::asset('assets/images/logo/login-logo.png')}}" alt="logo Indecks">
                </div>                        
            <div style="text-align: center; text-transform: uppercase;" class="login-title">Login Colaborador</div>

            <form method="POST" action="{{ route('user.login.submit') }}">
                {{ csrf_field() }}
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-addon">
                            <i class="fa fa-envelope"></i>
                        </div>
                        <input type="email" name="email" value="{{ old('email') }}" class="form-control" placeholder="Endereço de E-mail" autofocus>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-addon">
                            <i class="fa fa-unlock-alt"></i>
                        </div>
                        <input type="password" class="form-control" name="password" placeholder="Senha">
                    </div>
                </div>

                <div class="col-md-12">
                    @if ($errors->has('password'))
                        <span class="help-block">
                    <strong>{{ $errors->first('password') }}</strong>
                </span>
                    @endif
                    @if ($errors->has('email'))
                        <span class="help-block">
                        <strong>{{ $errors->first('email') }}</strong>
                    </span>
                    @endif
                    @if(Session::has('error'))
                        <div class="alert alert-danger alert-dismissable">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            {{ Session::get('error') }}
                        </div>
                    @endif
                </div>
                <div class="form-group text-center">

                    <button type="submit" class="btn btn-primary" name="button">
                  <span class="glyphicon glyphicon-log-in"></span> &nbsp; Entrar
                  </button>
                  <br><br>
                    <?php /*<p><a href="{{route('user.reg')}}" class="text-center">Criar uma nova conta</a></p> */?>

                    <?php /*<p><a href="{{route('user.forgotpass')}}">Esqueceu a senha?</a></p> */?>
                </div>
            </form>
        </div>
    </div>
</div>
</div>

    <div class="row">
                  <div class="col-lg-12">
                    <div class="login-footer text-center" style="margin-top: -30px;">
                      <b>Desenvolvido Por</b> <a style="font-weight: bold; color: #838383;" href="{{url('/')}}" target="_blank"><i class="fa fa-calendar" style="font-weight: bold; padding: 1px 4px;"></i> In <span style="color:#76b14c;">Decks</span></a>
                      <p style="font-weight: bold;">Copyright © <?php echo date('Y') ?> Todos os Direitos Reservados.</p>
                    </div>
                  </div>
                </div> 
</section>


@stop

@section('footer')

@stop