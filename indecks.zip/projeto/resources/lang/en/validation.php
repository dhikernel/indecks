<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the default error messages used by
    | the validator class. Some of these rules have multiple versions such
    | as the size rules. Feel free to tweak each of these messages here.
    |
    */

    'accepted'             => 'O atributo: deve ser aceito.',
    'active_url'           => 'O atributo: não é um URL válido.',
    'after'                => 'O atributo: deve ser uma data após: data.',
    'after_or_equal'       => 'O atributo: deve ser uma data posterior ou igual a: date.',
    'alpha'                => 'O atributo: só pode conter letras.',
    'alpha_dash'           => 'O atributo: só pode conter letras, números e traços.',
    'alpha_num'            => 'O atributo: pode conter apenas letras e números.',
    'array'                => 'O atributo: deve ser uma matriz.',
    'before'               => 'O atributo: deve ser uma data anterior: data.',
    'before_or_equal'      => 'O atributo: deve ser uma data anterior ou igual a: date.',
    'between'              => [
        'numeric' => 'O atributo: deve estar entre: min e: max.',
        'file'    => 'O atributo: deve estar entre: min e: max kilobytes.',
        'string'  => 'O atributo: deve estar entre: min e: max caracteres.',
        'array'   => 'O atributo: deve ter entre: min e: max itens.',
    ],
    'boolean'              => 'O campo: atributo deve ser verdadeiro ou falso.',
    'confirmed'            => 'A confirmação do atributo: não corresponde.',
    'date'                 => 'O atributo: não é uma data válida.',
    'date_format'          => 'O atributo: não corresponde ao formato: format.',
    'different'            => 'O atributo: e: outro deve ser diferente.',
    'digits'               => 'O atributo: deve ser: dígitos dígitos.',
    'digits_between'       => 'O atributo: deve estar entre: min e: max dígitos.',
    'dimensions'           => 'O atributo: tem dimensões de imagem inválidas.',
    'distinct'             => 'O campo: attribute possui um valor duplicado.',
    'email'                => 'O atributo: deve ser um endereço de e-mail válido.',
    'exists'               => 'O atributo selecionado: é inválido.',
    'file'                 => 'O atributo: deve ser um arquivo.',
    'filled'               => 'O campo: atributo deve ter um valor.',
    'image'                => 'O atributo: deve ser uma imagem.',
    'in'                   => 'O atributo selecionado: é inválido.',
    'in_array'             => 'O campo: atributo não existe em: other.',
    'integer'              => 'O atributo: deve ser um inteiro.',
    'ip'                   => 'O atributo: deve ser um endereço IP válido.',
    'json'                 => 'O atributo: deve ser uma string JSON válida.',
    'max'                  => [
        'numeric' => 'O atributo: não pode ser maior que: max.',
        'file'    => 'O atributo: não pode ser maior que: max kilobytes.',
        'string'  => 'O atributo: não pode ser maior que: caracteres máximos.',
        'array'   => 'O atributo: pode não ter mais que: itens máximos.',
    ],
    'mimes'                => 'O atributo: deve ser um arquivo do tipo:: values.',
    'mimetypes'            => 'O atributo: deve ser um arquivo do tipo:: values.',
    'min'                  => [
        'numeric' => 'O atributo: deve ser no mínimo: min.',
        'file'    => 'O atributo: deve ser pelo menos: min kilobytes.',
        'string'  => 'O atributo: deve ser pelo menos: min caracteres.',
        'array'   => 'O atributo: deve ter pelo menos: min itens.',
    ],
    'not_in'               => 'O atributo selecionado: é inválido.',
    'numeric'              => 'O atributo: deve ser um número.',
    'present'              => 'O campo: atributo deve estar presente.',
    'regex'                => 'O formato do atributo: é inválido.',
    'required'             => 'O campo: atributo é obrigatório.',
    'required_if'          => 'O :campo de atributo é obrigatório quando: o outro é: valor.',
    'required_unless'      => 'O :campo de atributo é obrigatório a menos que: other esteja em: values.',
    'required_with'        => 'O :campo de atributo é obrigatório quando: valores estão presentes.',
    'required_with_all'    => 'O :campo de atributo é obrigatório quando: valores estão presentes.',
    'required_without'     => 'O :campo de atributo é obrigatório quando: os valores não estão presentes.',
    'required_without_all' => 'O :campo de atributo é obrigatório quando nenhum dos valores está presente.',
    'same'                 => 'O :atributo e: outro deve corresponder.',
    'size'                 => [
        'numeric' => 'O :o atributo deve ser: size.',
        'file'    => 'O :o atributo deve ser: kilobytes de tamanho.',
        'string'  => 'O :o atributo deve ser: caracteres de tamanho.',
        'array'   => 'O :o atributo deve conter: itens de tamanho.',
    ],
    'string'               => 'O :atributo deve ser uma string.',
    'timezone'             => 'O :o atributo deve ser uma zona válida.',
    'unique'               => 'O :atributo já foi cadastrado.',
    'uploaded'             => 'O :atributo falhou ao fazer o upload.',
    'url'                  => 'O :o formato do atributo é inválido.',

    /*
    |--------------------------------------------------------------------------
    | Custom Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | Here you may specify custom validation messages for attributes using the
    | convention "attribute.rule" to name the lines. This makes it quick to
    | specify a specific custom language line for a given attribute rule.
    |
    */

    'custom' => [
        'attribute-name' => [
            'rule-name' => 'mensagem personalizada',
        ],
        'photo' => [
            'mimes' => 'A imagem de recurso deve ser um arquivo do tipo:: values.',
        ],
        'goal' => [
            'mimes' => 'O objetivo deve ser um valor válido.',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Custom Validation Attributes
    |--------------------------------------------------------------------------
    |
    | The following language lines are used to swap attribute place-holders
    | with something more reader friendly such as E-Mail Address instead
    | of "email". This simply helps us make messages a little cleaner.
    |
    */

    'attributes' => [],

];
