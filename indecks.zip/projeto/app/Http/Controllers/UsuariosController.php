<?php

namespace App\Http\Controllers;
use App\Settings;
use App\UserProfile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

class UsuariosController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $customers = UserProfile::orderBy('id','desc')->get();
        return view('admin.usuarioslista',compact('customers'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
        public function cadastrar()
    {
        return view('admin.usuariosadd');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */


    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),[
    
        ]);

        if ($validator->passes()) {
            $customer = new UserProfile;
            $customer->fill($request->all());

            $customer->save();
            Session::flash('message', 'Novo usuário adicionado com sucesso.');
            return redirect('admin/usuarios');
        }
    
    }
    
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $customer = UserProfile::findOrFail($id);
        return view('admin.usuariosdetalhes',compact('customer'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
      public function editar($id)
    {
        $customer = UserProfile::findOrFail($id);
        return view('admin.usuarioseditar',compact('customer'));
    }
    
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
     public function update(Request $request, $id)
    {
        $customer = UserProfile::findOrFail($id);
        $data = $request->all();               
        $customer->update($data);
        return redirect('admin/usuarios')->with('message','Usuário atualizado com sucesso!');;
    }

    public function status($id,$status)
    {
        $customer = UserProfile::findOrFail($id);
        $data['status']=$status;
        $customer->update($data);
        return redirect('admin/usuarios')->with('message','Status da conta do usuário alterado com sucesso!');
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */    
public function deletar($id)
    {
        $customer = UserProfile::findOrFail($id);        
        $customer->delete();
        return redirect('admin/usuarios')->with('message','Colaborador excluido com sucesso!');
    }

  /*
   public function destroy($id)
    {
        $customer = UserProfile::findOrFail($id);        
        $customer->delete();
        return redirect('admin/usuarios')->with('message','Usuários deletado com sucesso!');
    }
    */
}
