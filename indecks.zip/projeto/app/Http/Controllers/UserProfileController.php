<?php

namespace App\Http\Controllers;

use App\Country;
use App\UserProfile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class UserProfileController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:profile');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {        
       $customers = UserProfile::orderBy('id','desc')->get();
        return view('user.aniversarianteslista',compact('customers'));
    }

    public function profile()
    {
        $user = UserProfile::find(Auth::user()->id);        
        return view('user.userprofile', compact('user'));
    }

    public function password()
    {
        $user = UserProfile::find(Auth::user()->id);
        return view('user.userchangepass' , compact('user'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $user = UserProfile::findOrFail($id);
        $input = $request->all();
        if ($file = $request->file('foto')){
            $photo = time().$request->file('foto')->getClientOriginalName();
            $file->move('assets/images/userprofile',$photo);
            $input['foto'] = $photo;
        }       

        if ($request->cpass){
            if (Hash::check($request->cpass, $user->password)){

                if ($request->newpass == $request->renewpass){
                    $input['password'] = Hash::make($request->newpass);
                }else{
                    Session::flash('error', 'Confirme a senha, n�o correspondem.');
                    return redirect('usuario/perfil');
                }
            }else{
                Session::flash('error', 'Perfil do colaborador atualizado com sucesso!');
                return redirect('usuario/perfil');
            }
        }
        //return $request->cpass;
        //return "Not..";
        $user->update($input);
        Session::flash('message', 'Perfil do colaborador atualizado com sucesso!');
        return redirect('usuario/perfil');
    }

    public function changepass(Request $request, $id)
    {
        $user = UserProfile::findOrFail($id);
        $input['password'] = "";
        if ($request->cpass){
            if (Hash::check($request->cpass, $user->password)){

                if ($request->newpass == $request->renewpass){
                    $input['password'] = Hash::make($request->newpass);
                }else{
                    Session::flash('error', 'Confirme: A senha n�o corresponde.');
                    return redirect('usuario/mudar-senha');
                }
            }else{
                Session::flash('error', 'Senha atual n�o corresponde');
                return redirect('usuario/senha');
            }
        }

        $user->update($input);
        Session::flash('message', 'Senha da conta atualizada com sucesso.');
        return redirect('usuario/senha');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
