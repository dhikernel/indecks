<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Category;
use App\Country;
use App\Settings;
use App\UserProfile;
use App\Withdraw;
use Illuminate\Support\Facades\Auth;
use Validator;

class UsuarioAniversarianteController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:profile');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {        
       $customers = UserProfile::orderBy('id','desc')->get();
        return view('user.aniversarianteslista',compact('customers'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $customer = UserProfile::findOrFail($id);                    
        return view('user.aniversariantesdetalhes',compact('customer'));        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
    
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {



    }
   

    public function delete($id)
    {

     
    }


}
